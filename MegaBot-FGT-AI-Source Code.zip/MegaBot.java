import gameInterface.AIInterface;
import structs.FrameData;
import structs.GameData;
import structs.CharacterData;
import structs.Key;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.Random;

public class MegaBot implements AIInterface {

	String NomesBot[] = new String[3];
	float U[] = new float[3];
	int Posi = 0;
	int numBots = 3;
	boolean Unknow = false;
	FrameData Info;
	float d_max = 60;
	CharacterData P1,P2;
	GameData Ginfo;
	
	
	public int Result_Match(CharacterData P1, CharacterData P2, boolean arg1)
	{
		if(arg1) // if MegaBot is P1
		{
			if((P1.hp - P2.hp) > 0)
				return 1;
			else if((P1.hp - P2.hp) < 0)
				return -1;
			else if((P1.hp - P2.hp) == 0)
				return 0;
		}
		else if(!arg1) // if MegaBot is P2
		{
			if((P2.hp - P1.hp) > 0)
				return 1;
			else if((P2.hp - P1.hp) < 0)
				return -1;
			else if((P2.hp - P1.hp) == 0)
				return 0;	
		}
	}
	
	public int Diff_HP(CharacterData P1,CharacterData P2, boolean arg1)
	{
		if(arg1)
		{
			return (P1.hp - P2.hp) // MegaBot is P1
		}
		else if(!arg1)
		{
			return (P2.hp - P1.hp) // MegaBot is P2
		}
	}
	
	public float Reward(int TypeReward,GameData arg0, boolean arg1)
	{
		if(TypeReward == 1)
		{
			float d = Info.getRemainingTimeMilliseconds();
			if(Result_Match(P1,P2,arg1) == 1) // MegaBot won!!
			{
				return (1 - (d/d_max));
			}
			else if(Result_Match(P1,P2,arg1) == -1) // MegaBot lost :(
			{
				return ((d/d_max) - 1);
			}
			else if(Result_Match(P1,P2,arg1) == 0) // it's a tie!
			{
				return 0;
			}
		}
		else if(TypeReward == 2)
		{
			if(Result_Match(P1,P2,arg1) == 1) // MegaBot won!!
				return 1;
			else if(Result_Match(P1,P2,arg1) == -1) // MegaBot lost :(
				return -1;
			else if(Result_Match(P1,P2,arg1) == 0) // it's a tie!
				return 0;
		}
		else if(TypeReward == 3)
		{
			return Diff_HP(P1,P2,arg1);
		}
	}
	
	public void SelecaoBot(GameData arg0, boolean arg1){
		String nameBotFile = arg0.getOpponentName(!arg1);
		try
		{
			String PATH = System.getProperty("user.dir");
			PATH = PATH.substring(0,PATH.length() - 2);
			nameBotFile = nameBotFile + ".txt";
			PATH = PATH + nameBotFile;
			Scanner reader = new Scanner(new FileReader(nameBotFile)).useDelimiter("\\;\\n");
			int i = 0;
			
			while(reader.hasNext())
			{
				NomesBot[i] = reader.next();
				U[i] = reader.nextFloat();
				i++;
				if(U[Posi] < U[i])
				{
					Posi = i;
				}
				Random generator = new Random();
				int Prob = generator.nextInt(10);
				if(Prob == 1)  // A chance de 10% de n�o escolher o melhor
				{
					Prob = Posi;
					while(Prob != Posi)
					{
						Prob = generator.nextInt(3); // escolhe um novo Bot diferente do primeiro
					}
					Posi = Prob;
				}
				
				// Inicializar os Bots
				
			}
		}
		catch(FileNotFoundException ex)
		{
			
		}

	}
	
	
	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getCharacter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getInformation(FrameData arg0) {
		// TODO Auto-generated method stub
		if(!arg0.getEmptyFlag() && arg0.getRemainingTimeMilliseconds() > 0)
		{
			Info = arg0;
			P1 = Info.getP1();
			P2 = Info.getP2();
		}
	}

	@Override
	public int initialize(GameData arg0, boolean arg1) {
		// TODO Auto-generated method stub
		SelecaoBot(arg0,arg1);
		Ginfo = arg0;
		return 0;
	}

	@Override
	public Key input() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void processing() {
		// TODO Auto-generated method stub
			if(NomesBots[Posi] ==)
			{
				// C�digo do primeiro bot
			}
			else if(NomesBots[Posi] ==)
			{
				// C�digo do segundo Bot
			}
			else if(NomesBots[Posi] ==)
			{
				// C�digo do terceiro Bot
			}
		}
	}

}
